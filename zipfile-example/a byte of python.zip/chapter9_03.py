#! /usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2017/6/28 16:17
# @Author  : xiongyaokun
# @Site    : 
# @File    : chapter9_03.py
# @Software: PyCharm

# 'ab' is short for address book

ab = {'Swaroop':'swaroopch@byteofpython.info',
      'Larry':'larry@wall.org',
      'Matsumoto':'matz@ruby-lang.org',
      'Spammer':'spammer@hotmail.com'
      }
print "Swaroop's address is %s" % ab['Swaroop']

# Adding a key/value pair
ab['Guido'] = 'guido@python.org'

# Deleting a key/value pair
del ab['Spammer']
print '\nThere are %d contacts in the address-book\n' % len(ab)

for name, address in ab.items():
    print "Contact %s at %s" %(name, address)

if 'Guido' in ab:
    print "\nGuido's address in %s" % ab['Guido']