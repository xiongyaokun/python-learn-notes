#! /usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2017/6/28 15:46
# @Author  : xiongyaokun
# @Site    : 
# @File    : chapter9_02.py
# @Software: PyCharm

zoo = ('wolf', 'elephant', 'penguin', 'monkey')
print "Number of animals in the zoo is:", len(zoo)

new_zoo = ('monkey', 'dolphin', zoo)
print "Number of animals in the new zoo is:", len(new_zoo)
print "All animals in new zoo are:", new_zoo
print "Animals brought from old zoo are:", new_zoo[2]
print "Last animal brough from old zoo is:", new_zoo[2][-1]
