#! /usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2017/6/28 21:41
# @Author  : xiongyaokun
# @Site    : 
# @File    : chapter9_06.py
# @Software: PyCharm

message = "How are you?"

if message.startswith('How'):
    print "This string starts with 'How'."

if 'are' in message:
    print "'are' is in this string."

if message.endswith('you?'):
    print "This string ends with 'you?'"

if message.find('y') != -1:
    print "This string contains 'y'."

delimiter = '_*_'
mylist = ['Brazil', 'Russia', 'India', 'China']
print delimiter.join(mylist)