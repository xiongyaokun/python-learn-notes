#! /usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2017/6/28 14:53
# @Author  : xiongyaokun
# @Site    : 
# @File    : chapter9_01.py
# @Software: PyCharm

#This is my shopping list

shoplist = ['apple', 'mango', 'carrot', 'banana']
print 'I have',len(shoplist),'items to purchase.'

# Notice the comma at end of the line.
print 'These items are:',
for item in shoplist:
    # Notice the comma at end of the line.
    print item,

print '\nI also have to buy rice.'
shoplist.append('rice')
print "My shoplist now is:", shoplist

print "I will sort my shoplist now."
shoplist.sort()
print "Sorted shopping list is:", shoplist

print "The first item I will buy is", shoplist[0]
olditem = shoplist[0]
del shoplist[0]
print "I bought the", olditem

print "My shopping list now is:", shoplist
